package nuc.ss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot01HellowordApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot01HellowordApplication.class, args);
    }

}
