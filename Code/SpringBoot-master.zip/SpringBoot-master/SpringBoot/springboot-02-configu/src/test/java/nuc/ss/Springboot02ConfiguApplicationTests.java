package nuc.ss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot02ConfiguApplicationTests {

    @Test
    void contextLoads() {
    }

}
