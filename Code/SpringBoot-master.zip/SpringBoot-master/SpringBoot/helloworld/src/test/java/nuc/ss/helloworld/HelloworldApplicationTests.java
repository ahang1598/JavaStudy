package nuc.ss.helloworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//单元测试
@SpringBootTest
class HelloworldApplicationTests {

	@Test
	void contextLoads() {
	}

}
