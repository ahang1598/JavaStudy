package nuc.ss.service;

public interface TicketService {
    String getTicket();
}
