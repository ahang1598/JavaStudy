package nuc.ss.service;

import nuc.ss.pojo.User;

public interface UserService {

    public User queryUserByName(String name);
}
