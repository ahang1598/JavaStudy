//暴露一个方法
exports.sayHi = function() {
    document.write("<h1>狂神说ES6</h1>")
}