var hello = require("./hello");
hello.sayHi();