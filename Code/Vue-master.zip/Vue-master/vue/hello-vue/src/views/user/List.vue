<template>
    <div>
      <h1>用户列表页</h1>
    </div>
</template>

<script>
    export default {
        name: "UserList"
    }
</script>

<style scoped>

</style>
