<template>
  <div>
    <h1>首页</h1>
  </div>
</template>

<script>
    export default {
        name: 'Main'
    }
</script>

<style scoped>

</style>
