<template>
  <div>
    <h1>内容页</h1>
  </div>
</template>

<script>
  export default {
    name: "Content"
  }
</script>

<style scoped>

</style>
