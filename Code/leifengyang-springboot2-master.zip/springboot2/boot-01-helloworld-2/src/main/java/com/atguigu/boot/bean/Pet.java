package com.atguigu.boot.bean;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class Pet {
    private String name;
    private Double weight;
}
