package com.atguigu.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot01Helloworld2Application {

    public static void main(String[] args) {
        SpringApplication.run(Boot01Helloworld2Application.class, args);
    }

}
