package com.atguigu.admin.mapper;

import com.atguigu.admin.bean.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 *
 */
public interface UserMapper extends BaseMapper<User> {


}
