package com.xiaofan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot07SecurityApplicationTests {

    @Test
    void contextLoads() {
    }

}
