package com.xiaofan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot07SecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot07SecurityApplication.class, args);
    }

}
