package com.xiaofan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot05DataElasticsearchApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot05DataElasticsearchApplication.class, args);
    }

}
