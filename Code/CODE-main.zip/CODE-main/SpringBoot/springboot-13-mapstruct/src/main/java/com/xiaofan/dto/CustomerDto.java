package com.xiaofan.dto;

import lombok.Data;

@Data
public class CustomerDto {
    private Long id;
    private String customerName;
    private String disable;
}
