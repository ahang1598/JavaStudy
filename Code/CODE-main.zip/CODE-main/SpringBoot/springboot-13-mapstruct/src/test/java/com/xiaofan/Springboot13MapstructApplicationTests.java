package com.xiaofan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot13MapstructApplicationTests {

    @Test
    void contextLoads() {
    }

}
