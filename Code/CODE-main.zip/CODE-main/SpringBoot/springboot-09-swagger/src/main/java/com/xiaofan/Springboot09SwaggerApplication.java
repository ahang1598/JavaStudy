package com.xiaofan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot09SwaggerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot09SwaggerApplication.class, args);
    }

}
