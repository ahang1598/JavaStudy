package com.xiaofan.utils;

public class CommonConstant {
    public static final String INDEX = "test_jd_goods";
}
