package com.xiaofan.service;

public interface TicketService {

    String getTicket();
}
