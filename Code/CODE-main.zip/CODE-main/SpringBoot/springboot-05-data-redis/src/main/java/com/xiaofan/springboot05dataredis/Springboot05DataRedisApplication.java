package com.xiaofan.springboot05dataredis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot05DataRedisApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot05DataRedisApplication.class, args);
    }

}
