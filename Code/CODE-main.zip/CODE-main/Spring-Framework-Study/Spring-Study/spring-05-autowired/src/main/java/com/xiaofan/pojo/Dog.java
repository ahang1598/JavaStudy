package com.xiaofan.pojo;

public class Dog {

    public void shout() {
        System.out.println("wang~");
    }
}
