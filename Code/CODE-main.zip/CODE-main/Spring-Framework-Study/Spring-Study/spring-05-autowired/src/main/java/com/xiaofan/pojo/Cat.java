package com.xiaofan.pojo;

public class Cat {

    public void shout() {
        System.out.println("miao~");
    }
}
