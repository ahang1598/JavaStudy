package com.xiaofan.demo02;

public interface UserService {
    void add();
    void del();
    void update();
    void query();
}
