package com.xiaofan.demo01;

/**
 * 租房
 */
public interface Rent {
    void rent();
}
