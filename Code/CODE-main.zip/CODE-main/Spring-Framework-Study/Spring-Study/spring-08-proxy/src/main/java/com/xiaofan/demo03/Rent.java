package com.xiaofan.demo03;

/**
 * 租房
 */
public interface Rent {
    void rent();
}
