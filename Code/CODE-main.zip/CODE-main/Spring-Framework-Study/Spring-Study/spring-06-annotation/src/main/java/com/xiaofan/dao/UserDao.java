package com.xiaofan.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
}
