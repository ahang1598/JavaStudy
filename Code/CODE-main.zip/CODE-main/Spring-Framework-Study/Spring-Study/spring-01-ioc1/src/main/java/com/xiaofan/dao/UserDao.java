package com.xiaofan.dao;

public interface UserDao {
    void getUser();
}
