package com.xiaofan.service;

public interface UserService {
    void getUser();
}
