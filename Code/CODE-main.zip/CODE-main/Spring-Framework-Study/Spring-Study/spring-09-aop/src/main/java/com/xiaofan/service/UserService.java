package com.xiaofan.service;

public interface UserService {

    void add();
    void del();
    void update();
    void query();

}
