package com.xiaofan.dao;

import com.xiaofan.pojo.Student;

import java.util.List;

public interface StudentMapper {
}
