package com.xiaofan.dao;

import com.xiaofan.pojo.User;

public interface UserMapper {

    User getUserById(int id);

}
