## eureka
- 导入依赖
- 编写配置文件
- 开启这个功能 @EnableXXXX
- 配置类